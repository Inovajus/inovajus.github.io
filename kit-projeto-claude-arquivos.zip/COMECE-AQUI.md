# Monte o seu Projeto do zero — 15 minutos

Este é o kit do participante. Ele existe para que você saia da aula com **o seu Projeto criado**,
não com a lembrança de ter visto o Projeto de outra pessoa.

Você vai precisar de: uma conta no Claude (o plano gratuito cria Projeto), o navegador aberto e
quinze minutos. **Não precisa de nada instalado**, e não precisa de acesso à ApoIA para as cinco
primeiras etapas.

---

## Antes do primeiro clique: o que é um Projeto

Um chat comum esquece a sua unidade a cada conversa. Um **Projeto** é um lugar onde ficam guardadas
três coisas que não precisam mais ser repetidas:

| O que é | O que guarda | Onde fica |
|---|---|---|
| **Instruções** | Quem é a sua unidade, como o texto deve sair, o que nunca fazer | Campo de texto, escrito uma vez |
| **Conhecimento** | Os seus modelos, o seu estilo, as suas regras | Arquivos que você sobe |
| **Conector** | O acesso aos autos, quando houver | Ligado por conversa |

A frase que resume: **um Projeto não é um chat com nome — é um posto de trabalho.**

---

## Etapa 1 · Criar o Projeto (1 min)

1. Entre em `claude.ai`.
2. Na barra da esquerda, clique em **Projetos**.
3. Botão **Novo projeto**, no alto à direita.
4. Nome: escreva o que a unidade faz, não o que a ferramenta é. *"Secretaria da 2ª Vara — minutas"*
   é melhor que *"Teste IA"*.
5. Descrição: uma linha sobre o que você espera dele.

## Etapa 2 · Colar as instruções (3 min)

No painel da direita, em **Instruções**, clique no `+` e cole o texto do arquivo
`instrucoes-para-colar.txt` deste kit. Troque **apenas** o que está entre colchetes na primeira
linha: o nome da sua unidade e o sistema que você usa.

**Leia o que está colando.** É a única parte do Projeto que decide o comportamento dele — e você vai
querer ajustar depois da primeira semana de uso.

## Etapa 3 · Subir os arquivos de conhecimento (3 min)

Em **Contexto**, clique no `+` e escolha **Carregar do aparelho**. Suba os três arquivos da pasta
`exemplos/`:

| Arquivo | Para que serve | Quando trocar pelo seu |
|---|---|---|
| `00-minha-unidade.md` | Diz quem é a unidade e quem lê a minuta | Hoje mesmo — são 5 linhas |
| `01-meus-modelos.md` | Três modelos de exemplo, para o Projeto funcionar já | Assim que reunir os seus |
| `02-regras-de-dado.md` | Sigilo, conectores e injeção de prompt | Nunca: vale para qualquer unidade |

Os exemplos são **fictícios**, e existem para você ver o mecanismo funcionando antes de investir
tempo. O Projeto só fica bom quando `01-meus-modelos.md` virar o repertório real da sua unidade.

## Etapa 4 · O primeiro teste (2 min)

Abra uma conversa dentro do Projeto e peça:

```
Preciso intimar a parte autora para se manifestar sobre documento novo juntado aos
autos. Qual modelo do repertório se aplica, e como ficaria a minuta?
```

O que observar na resposta — e é isto que separa um Projeto que serve de um que engana:

- Ele **citou o nome do modelo** que usou? Se inventou um nome, a instrução não está sendo obedecida.
- O texto saiu **no formato do modelo**, com o fecho da casa?
- Todo dado factual veio marcado **`[CONFERIR]`**?
- Veio o bloco **CONFERÊNCIA** no fim, dizendo o que falta?

## Etapa 5 · O teste que importa mais (2 min)

Peça um ato para o qual **não existe modelo** no seu repertório:

```
Minute uma sentença de improcedência em ação de desapropriação.
```

A resposta certa é **"nenhum modelo do repertório se aplica"**. Se ele inventar um ato, o Projeto
está mentindo com aparência de competência — volte à Etapa 2 e confira se a instrução foi colada
inteira.

## Etapa 6 · Trocar os exemplos pelos seus modelos (4 min hoje, e uma tarde depois)

1. Junte numa pasta os **cinco atos que você mais repete no mês**. Cinco bastam.
2. Abra cada um, **apague todo dado de caso concreto** — nome de parte, CPF, número de processo,
   valores, endereço, telefone. Modelo de secretaria costuma vir com esses restos, e ninguém nota,
   porque internamente não é problema. Passa a ser quando o arquivo sai da casa.
3. Cole os cinco num arquivo de texto só, cada um com um título assim:

```
### Nome do modelo, como você o chama no PJe

(texto do modelo)
```

4. Suba no lugar de `01-meus-modelos.md`, e **apague o de exemplo**. Duas versões do mesmo insumo
   convivendo é a forma mais rápida de o Projeto aplicar a errada.

---

## As cinco armadilhas, na ordem em que costumam pegar

**1. O conector não fica salvo no Projeto.** Se você usar o MCP da ApoIA, a ativação é por conversa
(botão `+` › Conectores). Esquecer isso é receber uma minuta impecável — e sem os autos dentro.

**2. Vários conectores ligados.** Com dois ou três, o Claude decide sozinho de qual buscar. Deixe
ligado só o que a tarefa exige.

**3. O token da ApoIA vence em 8 horas contadas do login**, não da geração da URL. E **a URL é uma
chave**: não vai para grupo, documento compartilhado nem chamado de suporte.

**4. Duas versões do mesmo arquivo no Contexto.** Ao atualizar, apague o anterior.

**5. O Projeto envelhece em silêncio.** Modelo revogado que continua lá vira minuta errada com cara
de certa. Dez minutos de revisão por mês resolvem.

---

## O que este Projeto não faz

Não decide, não assina e **não dispensa a sua conferência**. A saída é rascunho de um modelo de
linguagem que não leu os autos com olhos humanos — e a supervisão do art. 19 da Resolução CNJ nº
615/2025 recai sobre quem assina o ato, não sobre quem operou a ferramenta.

E antes de conectar qualquer processo real: confirme que a sua conta garante **retenção zero e não
uso dos dados para treinamento**. Plano voltado ao consumidor final não oferece isso em contrato.
Até resolver, trabalhe com documento fictício — a mecânica é exatamente a mesma.
