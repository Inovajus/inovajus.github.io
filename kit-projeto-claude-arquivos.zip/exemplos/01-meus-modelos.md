# Meus modelos

> **Estes três modelos são fictícios e genéricos.** Servem para o Projeto funcionar já na primeira
> conversa, antes de você reunir o repertório da sua unidade. **Troque-os pelos seus** — e, ao
> trocar, apague este arquivo: dois repertórios convivendo é a forma mais rápida de o Projeto usar
> o errado.
>
> O formato é o que importa: **um `###` com o nome do modelo, depois o texto**. É por esse título
> que o Projeto encontra o modelo certo.

---

### Despacho - Intimação para manifestação sobre documento novo

Intime-se a parte contrária para, no prazo de 15 (quinze) dias, manifestar-se sobre o documento
juntado aos autos, nos termos do art. 437, § 1º, do CPC.

Decorrido o prazo, com ou sem manifestação, certifique-se e voltem-me conclusos.

Expedientes.

[Cidade], data do sistema.

---

### Certidão - Decurso de prazo

Certifico que decorreu o prazo assinalado sem que a parte [PARTE] apresentasse manifestação nos
autos.

O referido é verdade e dou fé.

[Cidade], data do sistema.

---

### Ofício - Requisição de informações a órgão público

Senhor(a) [AUTORIDADE],

Nos autos do processo em epígrafe, solicito a Vossa Senhoria que, no prazo de 10 (dez) dias,
preste as informações a seguir especificadas, encaminhando os documentos que as comprovem:

a) [primeira informação requisitada];
b) [segunda informação requisitada].

As informações devem ser encaminhadas exclusivamente por meio eletrônico, aos autos do processo
indicado no cabeçalho.

Atenciosamente,

[Cidade], data do sistema.

---

## Como preparar os seus, quando chegar a hora

1. Junte os **cinco atos que você mais repete no mês**. Cinco bastam para o Projeto ficar útil.
2. Em cada um, apague todo dado de caso concreto: nome de parte, CPF, número de processo, valores,
   endereço, telefone. **Modelo de secretaria costuma vir com esses restos** — internamente ninguém
   nota, porque internamente não é problema. Passa a ser quando o arquivo sai da casa.
3. Cole os cinco aqui, cada um com o seu `###` e o nome exato que a sua unidade usa no sistema.
4. Suba no lugar deste arquivo e **apague o de exemplo**.
