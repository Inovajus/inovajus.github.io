# Quem é esta unidade

> **Preencha as cinco linhas abaixo e apague este aviso.** São cinco minutos, e é o que separa
> uma minuta genérica de uma que a sua unidade reconhece como sua.

**Unidade:** [ex.: Secretaria da 2ª Vara Federal da Seção Judiciária do Ceará]
**Sistema:** [ex.: PJe 2.x]
**Quem lê a minuta:** [ex.: o servidor que confere e submete ao magistrado]
**Matérias mais frequentes:** [ex.: execução fiscal, cumprimento de sentença, saúde]
**Cidade do fecho:** [ex.: Fortaleza]

## Como esta unidade escreve

- **Fecho padrão:** [ex.: "Expedientes." e, na linha seguinte, "Fortaleza, data do sistema."]
- **Prazos:** por extenso entre parênteses — *no prazo de 15 (quinze) dias*. O número vem do
  modelo ou da lei, nunca da frequência.
- **Como se refere às partes:** [ex.: *a parte autora*, *o exequente* — sem nome próprio no corpo]
- **O que nunca aparece nos atos daqui:** [ex.: data escrita à mão, saudação, negrito]

## Erros recorrentes que já corrigimos

*Este é o item de maior retorno do arquivo, e o que ninguém escreve. Uma linha por erro.*

- [ex.: prazo de 15 dias em ato que pede 5 — conferir sempre no dispositivo citado]
- 
